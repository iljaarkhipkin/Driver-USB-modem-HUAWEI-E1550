/*
 *  Copyright (C) 2009 ChenL
 *
 *  switch_modem.c
 *  Switch HUAWEI series modem from storage to modem device.
 *  To compile:
 *   gcc switch_modem.c -lusb -o switch_huawei
 */

#include <stdio.h>
#include "usb.h"

#define   HUAWEI_VENDOR   0x12d1
#define   HUAWEI_PRODUCT   0x1446 /* Change this to your own device ID! */

static usb_dev_handle *udev;

/*
 * Not sure what's purpose of this command. But we need it. The device
 * seems to perform a reset upon receiving it.
 */
int send_bulk_command()
{
   unsigned char command[] = {0x55, 0x53, 0x42, 0x43, 0x78, 0x56, 0x34, 0x12, 0x01, 0x00, 0x00, 0x00, 0x80, 0x00, 0x06, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
/*      0x55, 0x53, 0x42, 0x43, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x11,
      0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
*/
   };
   
   if (usb_claim_interface(udev, 0) != 0) {
      printf("Fail to claim interface: %d\n", usb_strerror());
      return (-1);
   }

   if ((usb_clear_halt(udev, 0x81) != 0) ||
       (usb_clear_halt(udev, 0x01) != 0)) {
      printf("Fail to clear halt: %s\n", usb_strerror());
      return (-1);
   }

   if (usb_bulk_write(udev, 0x01, (char *)command, 31, 0) != 0) {
      printf("Fail to send SCSI command: %s\n", usb_strerror());
   }
}

int main(void)
{
   struct usb_bus *bus;
   struct usb_device *dev;

   usb_init();

   usb_find_busses();
   usb_find_devices();

   printf("bus/device  idVendor/idProduct\n");

   for (bus = usb_busses; bus; bus = bus->next) {
      for (dev = bus->devices; dev; dev = dev->next) {
         int i, ret;
         char string[256];

         printf("%s/%s     %04X/%04X\n", bus->dirname,
             dev->filename, dev->descriptor.idVendor,
             dev->descriptor.idProduct);

         udev = usb_open(dev);
         if (udev) {
            if (dev->descriptor.iManufacturer) {
               ret = usb_get_string_simple(udev,
                   dev->descriptor.iManufacturer,
                   string, sizeof(string));
               if (ret > 0)
                  printf("- Manufacturer : %s\n",
                      string);
               else
                  printf("- Unable to fetch"
                      " manufacturer string %d\n",
                      ret);
            }


            if (dev->descriptor.iProduct) {
               ret = usb_get_string_simple(udev,
                   dev->descriptor.iProduct,
                   string, sizeof(string));
               if (ret > 0)
                  printf("- Product      : %s\n",
                      string);
               else
                  printf("- Unable to fetch"
                      " product string\n");
            }

            if (dev->descriptor.iSerialNumber) {
               ret = usb_get_string_simple(udev,
                   dev->descriptor.iSerialNumber,
                   string, sizeof(string));
               if (ret > 0)
                  printf("- Serial Number: %s\n",
                      string);
               else
                  printf("- Unable to fetch serial"
                      " number string\n");
            }

            if ((dev->descriptor.idVendor == HUAWEI_VENDOR)
                && (dev->descriptor.idProduct == HUAWEI_PRODUCT)) {
               int rval;

               rval = usb_control_msg(udev,
                   USB_TYPE_STANDARD | USB_RECIP_DEVICE,
                   USB_REQ_SET_FEATURE,
                   1, /* wValue */
                   0, /* wIndex */
                   0, /* wLength */
                   0, /* size */
                   0  /* timeout */);

               if (rval != 0) {
                  printf("Can't switch the modem's"
                      " configuration \n");
               } else {
                  printf("Switch Huawei modem's"
                      " config successfully\n");
               }

               send_bulk_command();

               usb_close(udev);

               goto done;
            }

            printf("No matching devices found!\n");

            usb_close(udev);
         }
      }
   }

done:
   return 0;
}

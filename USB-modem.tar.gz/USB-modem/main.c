/* 
 * File:   main.c
 * Author: ilya
 *
 * Created on 16 Январь 2012 г., 19:55
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

